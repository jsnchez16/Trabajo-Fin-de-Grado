import socket
import rclpy
import sys
import time

from rclpy.node import Node
from rclpy.action import ActionClient
from action_msgs.msg._goal_status import GoalStatus
from rclpy.qos  import qos_profile_sensor_data

from irobot_create_msgs.action import Dock, Undock, RotateAngle, DriveDistance
from irobot_create_msgs.msg import LedColor, LightringLeds, IrIntensityVector, DockStatus

from builtin_interfaces.msg import Duration

import math, struct

PUERTO = 8080

#ÓRDENES
SAL_DE_CASA = "SAL DE CASA"
VE_A_CASA = "VE A CASA"
AVANZA = "AVANZA"
PARA = "PARA"
GIRAIZQ = "GIRA A LA IZQUIERDA"
GIRADER = "GIRA A LA DERECHA"
GIRA180 = "DA LA VUELTA"
PARA = "PARA"

#DISTANCIA EN METROS A AVANZAR
DISTANCIA = ["UN", "DOS", "TRES", "CUATRO", "CINCO", "SEIS", "SIETE", "OCHO", "NUEVE", "DIEZ"]

FLAG_CASA = True 

#Action clients trabajan en conjunción con action servers. Los action clients
#envian un goal request a un action server que ejecutará la acción y enviará
#el feedback y los resultados al cliente posteriormente

#Clase que hereda de la clase Node de la biblioteca rclpy
class OrdenesClient(Node):

    def __init__(self):
        super().__init__('ordenes_client')
        self._dock_client = ActionClient(self, Dock, 'dock')
        self._undock_client = ActionClient(self, Undock, 'undock')
        self._girar_client = ActionClient(self, RotateAngle, '/rotate_angle')
        self._mover_client = ActionClient(self, DriveDistance, '/drive_distance')
        
        #self.subscription = self.create_subscription(DockStatus, '/dock_status', self.estadoCasa_callback, qos_profile_sensor_data)

        self.lights_publisher = self.create_publisher(LightringLeds, '/cmd_lightring', 10)
        self.lightring = LightringLeds()    #Definición de los mensajes del anillo LED  
        self.lightring.override_system = True #Esto nos permite cambiar el color de las luces

    def led_callback(self, r, g , b):
        self.lightring.leds = [LedColor(red = r, green = g, blue = b), LedColor(red = r, green = g, blue = b)
        , LedColor(red = r, green = g, blue = b), LedColor(red = r, green = g, blue = b), LedColor(red = r, green = g, blue = b)
        , LedColor(red = r, green = g, blue = b)]

        self.lights_publisher.publish(self.lightring)
        time.sleep(1)
        self.lights_publisher.publish(self.lightring)
        time.sleep(1)

    #Sal de casa
    def undock(self):
        goal_msg = Undock.Goal() #Instancia de la clase goal
        
        if not self._undock_client.wait_for_server(timeout_sec=5.0):
            raise Exception("No se ha encontrado el servidor de acción")

        self.led_callback(r=0, g=255, b=0)
        instFuture = self._undock_client.send_goal_async(goal_msg)  #Devuelve un objeto de tipo Future
        self.led_callback(r=255, g=255, b=255)

        global FLAG_CASA 
        FLAG_CASA = False

        return instFuture    

    #Ve a casa
    def dock(self):   
        goal_msg = Dock.Goal()

        if not self._dock_client.wait_for_server(timeout_sec=5.0):
            raise Exception("No se ha encontrado el servidor de acción")

        self.led_callback(r=0, g=255, b=0)
        instFuture = self._dock_client.send_goal_async(goal_msg)
        self.led_callback(r=255, g=255, b=255)

        global FLAG_CASA 
        FLAG_CASA = True

        return instFuture

    #Estado del Dock
    def estadoCasa_callback(self, msg:DockStatus):

        if msg.is_docked == True:
            print("Estoy en casa")
            
        else:
            print("Estoy fuera de casa")

    #Avanza recto
    def recto(self, mts):
        
        goal_msg = DriveDistance.Goal()
        goal_msg.distance = mts
        goal_msg.max_translation_speed = 0.15

        if not self._mover_client.wait_for_server(timeout_sec=5.0):
            raise Exception("No se ha encontrado el servidor de acción")

        self.led_callback(r=0, g=255, b=0)
        self._send_goal_future = self._mover_client.send_goal_async(goal_msg)
        self.led_callback(r=255, g=255, b=255)

        return self._send_goal_future

    #Gira a la izquierda
    def girarIZQ(self):
        angle = 1.5708  #Radianes
        speed = 1.0

        goal_msg = RotateAngle.Goal()
        goal_msg.angle = angle
        goal_msg.max_rotation_speed = speed

        if not self._girar_client.wait_for_server(timeout_sec=5.0):
            raise Exception("No se ha encontrado el servidor de acción")

        self.led_callback(r=0, g=255, b=0)
        instFuture = self._girar_client.send_goal_async(goal_msg)
        self.led_callback(r=255, g=255, b=255)

        return instFuture

    #Gira a la derecha
    def girarDER(self):
        angle = -1.5708
        speed = 1.0

        goal_msg = RotateAngle.Goal()
        goal_msg.angle = angle
        goal_msg.max_rotation_speed = speed

        if not self._girar_client.wait_for_server(timeout_sec=5.0):
            raise Exception("No se ha encontrado el servidor de acción")

        self.led_callback(r=0, g=255, b=0)
        instFuture = self._girar_client.send_goal_async(goal_msg)
        self.led_callback(r=255, g=255, b=255)

        return instFuture

    #Date la vuelta
    def girar180(self):
        
        angle = 3.14159
        speed = 1.0

        goal_msg = RotateAngle.Goal()
        goal_msg.angle = angle
        goal_msg.max_rotation_speed = speed

        if not self._girar_client.wait_for_server(timeout_sec=5.0):
            raise Exception("No se ha encontrado el servidor de acción")

        self.led_callback(r=0, g=255, b=0)
        instFuture = self._girar_client.send_goal_async(goal_msg)
        self.led_callback(r=255, g=255, b=255)

        return instFuture

class ServidorROS():
  
    #Definición del constructor de la subclase
    def __init__(self): 
        
        self.sc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sc.bind(("", PUERTO))
        self.sc.listen()
        
        print("Servidor iniciado. Esperando órdenes ...")

    def write_utf8(self, s: str, sock: socket.socket):
        encoded = s.encode(encoding='utf-8')
        sock.sendall(struct.pack('>i', len(encoded)))
        sock.sendall(encoded)

    def run(self):
        
        orden_client = OrdenesClient()

        while True:                             #Bucle para mantener el servidor activo
            cliente, addr = self.sc.accept()    #Tiene que estar ahí, antes de while rompe
            try: 
                data = cliente.recv(1024)
                if not data:
                    break;
                    
                mensajeRecibido = data.decode("utf-8").upper() #Se recoge en forma de String

                if SAL_DE_CASA in mensajeRecibido:
                    if FLAG_CASA == True:
                        print("Saliendo de casa")
                        
                        future = orden_client.undock()
                        
                        #Respuesta a la aplicación
                        mensajeEnviado = "OK"
                        self.write_utf8(mensajeEnviado, cliente)

                    else:
                        print("Ya estoy fuera de casa")
                        mensajeEnviado = "KO"
                        self.write_utf8(mensajeEnviado, cliente)

                elif VE_A_CASA in mensajeRecibido:
                    if FLAG_CASA == False:
                        print("Volviendo a casa")

                        future = orden_client.dock()

                        mensajeEnviado = "OK"
                        self.write_utf8(mensajeEnviado, cliente)

                    else:
                        print("Ya estoy en casa")
                        mensajeEnviado = "KO"
                        self.write_utf8(mensajeEnviado, cliente)
                        
                elif AVANZA in mensajeRecibido:
                    if FLAG_CASA == False:
                        metros = mensajeRecibido.split(' ')[2-1]

                        i = 0;
                        mts = None

                        for aux in DISTANCIA:
                            if aux == metros:
                                print("Avanzando " + metros + " metros")
                                mts = i+1.0

                                future = orden_client.recto(mts)

                                mensajeEnviado = "OK"
                                self.write_utf8(mensajeEnviado, cliente)

                                break;
                            else: 
                                i+=1
                                if i > 9:
                                    print("No puedo avanzar tanto")
                                    mensajeEnviado = "KO"
                                    self.write_utf8(mensajeEnviado, cliente)
                                    break;
                    else:
                        print("No puedo, estoy en casa")
                        mensajeEnviado = "KO"
                        self.write_utf8(mensajeEnviado, cliente)

                elif GIRAIZQ in mensajeRecibido:
                    if FLAG_CASA == False:
                        print("Girando a la izquierda")

                        future = orden_client.girarIZQ()

                        mensajeEnviado = "OK"
                        self.write_utf8(mensajeEnviado, cliente)

                    else:
                        print("No puedo, estoy en casa")
                        mensajeEnviado = "KO"
                        self.write_utf8(mensajeEnviado, cliente)

                elif GIRADER in mensajeRecibido:
                    if FLAG_CASA == False:
                        print("Girando a la derecha")

                        future = orden_client.girarDER()

                        mensajeEnviado = "OK"
                        self.write_utf8(mensajeEnviado, cliente)

                    else:
                        print("No puedo, estoy en casa")
                        mensajeEnviado = "KO"
                        self.write_utf8(mensajeEnviado, cliente)

                elif GIRA180 in mensajeRecibido:
                    if FLAG_CASA == False:
                        print("Dando la vuelta")

                        future = orden_client.girar180()

                        mensajeEnviado = "OK"
                        self.write_utf8(mensajeEnviado, cliente)

                    else:
                        print("No puedo, estoy en casa")
                        mensajeEnviado = "KO"
                        self.write_utf8(mensajeEnviado, cliente)

                elif PARA in mensajeRecibido:
                    print("Parando")
                    mts = 0.0

                    future = orden_client.recto(mts)

                    mensajeEnviado = "OK"
                    self.write_utf8(mensajeEnviado, cliente)

                else:
                    print("No entiendo esa orden")
                    mensajeEnviado = "KO"
                    self.write_utf8(mensajeEnviado, cliente)
                    orden_client.led_callback(r=255, g=0, b=0)
                    orden_client.led_callback(r=255, g=255, b=255)

            except ConnectionResetError:
                self.get_logger().warn(f"Error de conexión")
                break;

    def __del__(self):
        self.sc.close()

#La función main inicializa el contexto de rclpy
def main(args=None):

    rclpy.init(args = args)             
    servidorROS = ServidorROS()
    
    try:
        servidorROS.run()
    except KeyboardInterrupt:
        print('\nSe ha pulsado salir')
    finally:
        print('Saliendo')

if __name__ == '__main__':
    main()