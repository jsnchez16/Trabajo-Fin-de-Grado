"""sub_ir.py
Subscriber example
Cómo suscribirnos a un topic en ROS 2 usando el Create 3
Suscripción a los 7 sensores infrarrojos para mostrar la información
relevante en la terminal. Útil para evitar obstáculos
"""

import rclpy #Este módulo da acceso a la librería de python de ROS Client
import sys	 #
import time
from rclpy.node import Node
from rclpy.qos  import qos_profile_sensor_data #Quality of Service para
											   #el nodo sepa el tipo de 
											   #información que va a usar
from irobot_create_msgs.msg import IrIntensityVector

class IRSubscriber(Node):
	def __init__(self):	
		super().__init__('IR_subscriber')	#Se llama al constructor de la clase nodo
		#y declara el nombre del nodo 'IR...'
		print('Creando suscripción al tipo IrIntensityVector sobre el topic /ir_intensity')
		#Creamos el suscriptor
		self.subscription = self.create_subscription(IrIntensityVector, '/ir_intensity', self.listener_callback, qos_profile_sensor_data)

	def printIR(self, msg):
		
		print('Mostrando lecturas del sensor IR: ')
		for reading in msg.readings:
			val = reading.value
			if(val >= 250):
				print('Obstáculo encontrado')
				print('IR sensor; ' + str(val))

			print('IR sensor; ' + str(val))
		time.sleep(0.5)

	def listener_callback(self, msg:IrIntensityVector):
		print('Escuchando las lecturas del sensor IR ...')
		self.printIR(msg)

def main(args = None):
	rclpy.init(args = args)
	IR_subscriber = IRSubscriber()

	try:
		rclpy.spin(IR_subscriber)
	except KeyboardInterrupt:
		print('\n Se ha pulsado salir')
	finally:
		print('HECHO')
		IR_subscriber.destroy_node()
		
if __name__ == '__main__':
	main()